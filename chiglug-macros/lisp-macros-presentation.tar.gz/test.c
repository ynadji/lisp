#include <stdio.h>

#define SUM(x,y) (x + y)

int main(int argc, char **argv)
{
	printf("SUM(3,4) == %d\n", SUM(3,4));

	return 0;
}
